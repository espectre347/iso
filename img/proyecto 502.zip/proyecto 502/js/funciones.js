$(document).ready(function(){
    // evento click inicio
    $("#menuInicio").click(function(event){
        $("#divInicio").show("slow");
        $("#divFormulario").hide("slow");
    });
    //evento click del menu usuario
    $("#menuUsuario").click(function(event){
        $("#divInicio").hide("slow");
        $("#divFormulario").show("slow");
        
    });
    //evento del boton  Agregar
    $("#btnAgregar").click(function(event){
        var nombre, edad, clave;
        //guardamos los datos de las cajas de texto 
        clave=$("#txtClave").val();
        nombre=$("#txtNombre").val();
        edad=$("#txtEdad").val();
        accion="agregarUsuario";
        //usamos ajax para el envio de los datos al servidor
        $.ajax({
            url:"./php/servidor.php",
            type:"GET",
            data:{clave:clave, nombre:nombre, edad:edad, accion:accion},
            success:function(respuestaServidor){
                //comparamos que el servidor regrese un 1
                if(respuestaServidor=="1"){
                    alert("Registro exitoso");
                }
                else{
                    alert("No se registro el dato");
                }
            }

        });

    });
});


