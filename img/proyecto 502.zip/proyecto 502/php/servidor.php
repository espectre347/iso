<?php
    include "conexion.php";
    //recibimos la accion a realizar
    //enviado desde el formulario
    $accion=$_GET["accion"];
    //evaluamos la accion
    switch($accion){
        case 'agregarUsuario':
            //recibimos los datos enviados por el formulario
            $clave=$_GET["clave"];
            $nombre=$_GET["nombre"];
            $edad=$_GET["edad"];
            // se especifica el sql a realizar
            $sql="insert into usuario values(0, '$clave','$nombre', '$edad')";
            //ejecutar la sentencia
            $ejecutaSQL=$conexion->query($sql);
            //comprobamos si la ejecucion fue correcta
            if($ejecutaSQL){
                echo "1";
            }
            else
            {
                echo "0";
            }
            break;
    
        }

?>